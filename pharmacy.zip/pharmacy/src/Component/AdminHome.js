import React from "react";
import Navbar3 from "./Navbar3";
function AdminHome(){
return(
    <div >
        <Navbar3/>
    </div>
)
}
 
export default AdminHome;