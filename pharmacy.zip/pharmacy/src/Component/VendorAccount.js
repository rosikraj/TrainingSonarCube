import React from "react";
import Navbaradmin from "./Navbaradmin";
function VendorAccount(){
return(
    <div>
        <Navbaradmin/>
       Vendor Account
    </div>
)
}
 
export default VendorAccount