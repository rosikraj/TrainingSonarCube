import React from "react";
import Navbar from "./Navbar";
function Report(){
return(
    <div>
        <Navbar/>
        Report
    </div>
)
}
 
export default Report