import React from "react";
import Navbar3 from "./Navbar3";
function AdminAccount(){
return(
    <div >
        <Navbar3/>
    </div>
)
}
 
export default AdminAccount;