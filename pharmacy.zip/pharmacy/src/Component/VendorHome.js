import React from "react";
import Navbaradmin from "./Navbaradmin";
function VendorHome(){
return(
    <div>
        <Navbaradmin/>
        VendorHome
    </div>
)
}
 
export default VendorHome