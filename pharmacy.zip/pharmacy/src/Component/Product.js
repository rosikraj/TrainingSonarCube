import React from "react";
import Navbaradmin from "./Navbaradmin";
function Product(){
return(
    <div>
        <Navbaradmin/>
        Product
    </div>
)
}
 
export default Product;