import ChatBot from 'react-simple-chatbot';
import { ThemeProvider } from 'styled-components';
 
const steps = [
    {
        id: '0',
        message: 'Hello User!',
 
        // This calls the next id
        // i.e. id 1 in this case
        trigger: '1',
    }, {
        id: '1',
 
        // This message appears in
        // the bot chat bubble
        message: 'Please write your username',
        trigger: '2'
    }, {
        id: '2',
 
        // Here we want the user
        // to enter input
        user: true,
        trigger: '3',
    }, {
        id: '3',
        message: " hi {previousValue}, how can I help you?",
        trigger: '4'
    },  {
        id: '4',
        options: [
           
            // When we need to show a number of
            // options to choose we create alist
            // like this
            { value: 1, label: 'Delivery time',trigger: 5 },
            { value: 2, label: 'What do I do If I forget my password',trigger: 6},
            { value: 3, label: 'What are the hours of operation for Pharma-Easy',trigger: 7},
            { value: 4, label: 'Where is the nearest pharmacy to my location?',trigger: 8},
 
 
        ],
    },{
            id: '5',
            message: 'It takes less than 10 minutes to deliver the medicine to your doorstep',
            trigger: '4'
       
    },{
 
        id: '6',
        message: '24x7 Support online ',
        trigger: '4',
       
    },{
 
        id: '7',
        message: 'Please contact our online appointment based doctor for your in-person meet',
        trigger: '4',
       
    },{
 
        id: '8',
        message: 'Turn on your live location so that we could find you our nearest pharmacy location',
        trigger: '4',
    },
 
];
 
// Creating our own theme
const theme = {
    background: 'green',
    headerBgColor: 'green',
    headerFontSize: '20px',
    botBubbleColor: 'white',
    headerFontColor: 'white',
    botFontColor: 'black',
    userBubbleColor: 'green',
    userFontColor: 'white',
};
 
// Set some properties of the bot
const config = {
    botAvatar: "./logo_PE.png",
    floating: true,
};
 
function ChatBotPharmaEasy() {
    return (
        <div className="App">
            <ThemeProvider theme={theme}>
                <ChatBot
 
                    // This appears as the header
                    // text for the chat bot
                    headerTitle="Bot"
                    steps={steps}
                    {...config}
 
                />
            </ThemeProvider>
        </div>
    );
}
 
export default ChatBotPharmaEasy;
