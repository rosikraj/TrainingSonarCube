import React, { useState } from 'react';
import axios from 'axios';
import Navbaradmin from "./Navbaradmin";
// import './App.css';
function AddProduct(){
    const [formData, setFormData] = useState({
        productid: '',
        pname:'',
        manufacturedate: '',
        expirydate: '',
        price: '',
        quantity: '',
        stock: ''
      });
     
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
          ...prevData,
          [name]: value,
        }));
      };
     
      const handleSubmit = async () => {
        try {
    const response = await axios.post('http://localhost:8080/save', formData);
     
          if (response.status === 200) {
            console.log('User registered successfully');
          } else {
            console.error('Failed to register user');
          }
        } catch (error) {
          console.error('Error during registration:', error);
        }
      };
     
      return (
        <div className="App">
             <Navbaradmin/>
          <h1>Add Product</h1>
          <form onSubmit={handleSubmit}>
            <label> Product ID</label>
            <input type="text" name="productid" onChange={handleChange} /><br/>
            <label> Product Name</label>
            <input type="text" name="pname" onChange={handleChange} /><br/>
            <label> manufacture Date</label>
            <input type="date" name="manufacturedate" onChange={handleChange} /><br/>
            <label>Expiry Date</label>
            <input type="date" name="expirydate" onChange={handleChange} /><br/>
            <label>price</label>
            <input type="text" name="price" onChange={handleChange} /><br/>
            <label>Quantity</label>
            <input type="text" name="quantity" onChange={handleChange} /><br/>
            <label>Stock</label>
            <input type="text" name="stock" onChange={handleChange} /><br/>
            <button type="button" onClick={handleSubmit}>
              Submit
            </button>
          </form>
        </div>
      );
    }
export default AddProduct;