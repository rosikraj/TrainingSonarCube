import React from "react";
import Navbaradmin from "./Navbaradmin";

function VendorAccount() {
  return (
    <div>
      <Navbaradmin />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="bg-white p-4 rounded-md shadow-md">
          <img
            src="https://thumbs.dreamstime.com/b/admin-icon-trendy-design-style-isolated-white-background-vector-simple-modern-flat-symbol-web-site-mobile-logo-app-135742404.jpg"
            alt="Product 1"
            className="w-full h-30 object-cover mb-4 rounded-md"
          />
          <h3 className="text-xl font-semibold mb-2">Vendor1</h3>
          <p className="text-gray-700 mb-4">
            Medicare Person
          </p>
          <p className="text-blue-500 font-semibold">Vendor Id</p>
          <p className="text-blue-500 font-semibold">Address</p>
          <p className="text-blue-500 font-semibold">Phone Nmber</p>
        </div>

        {/* Add more featured product cards as needed */}
      </div>
    </div>
  );
}

export default VendorAccount;