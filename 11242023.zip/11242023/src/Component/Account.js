import React from "react";
import Navbar from "./Navbar";
function Account(){
return(
    <div >
        <Navbar/>
        Hii Customer
    </div>
)
}
 
export default Account;